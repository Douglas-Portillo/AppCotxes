package Model;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Cotxe {

    private String name;
    private Image imgSrc;

    private String color;

    private String any;

    private  String quilometres;

    private String combustible;

    private String motor;

    private String preu;

    public String getAny() {
        return any;
    }

    public void setAny(String any) {
        this.any = any;
    }

    public String getQuilometres() {
        return quilometres;
    }

    public void setQuilometres(String quilometres) {
        this.quilometres = quilometres;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getPreu() {
        return preu;
    }

    public void setPreu(String preu) {
        this.preu = preu;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Image getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(Image imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
