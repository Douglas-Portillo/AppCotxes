package com.example.projecte_uf2_m07;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class ControllerDesktopContactarVenedor {

    @FXML
    private Button enrere;

    public void closeWindows() throws IOException {

        FXMLLoader loader = new FXMLLoader(AppDesktop.class.getResource("Cotxes_Desktop.fxml"));

        Parent root = loader.load();

        Scene scene = new Scene(root);
        Stage stage = new Stage();

        stage.setScene(scene);
        stage.show();

        Stage myStage = (Stage) this.enrere.getScene().getWindow();
        myStage.close();

    }


}
