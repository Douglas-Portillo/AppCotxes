package com.example.projecte_uf2_m07;

import Model.Cotxe;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Stack;

public class ControllerMobil implements Initializable {

    @FXML
    private VBox cotxeEscollit;

    @FXML
    private ImageView cotxeImg;

    @FXML
    private Label nomCotxe;

    @FXML
    private GridPane grid;

    @FXML
    private ScrollPane scroll;

    private List<Cotxe> cotxe = new ArrayList<>();

    private Image image;

    private ListenerCotxe listener;

    @FXML
    private Label any;

    @FXML
    private Label quilometres;

    @FXML
    private Label combustible;

    @FXML
    private Label motor;

    @FXML
    private Label preu;

    @FXML
    private ImageView compte;

    @FXML
    private Button enrere;

    @FXML
    private Button btnPujarCotxe;

    @FXML
    private ImageView btnDadesUsuari;

    @FXML
    private ImageView btnMissatges;

    private List<Cotxe> getData(){

        List<Cotxe> cotxes = new ArrayList<>();
        Cotxe cotxe;

        String nomsCotxes[] = {"Peugeot 3008","Mazda 3","Citroen C3","Fiat 500","Lexus NX",
                "SEAT Tarraco","BMW Serie 3","Ford Focus","BMW X2","Peugeot 208"};

        String imatgesCotxes[] = {"/images/1.jpg","/images/2.jpg","/images/3.jpg","/images/4.jpg","/images/5.jpg",
                "/images/6.jpg","/images/7.jpg","/images/8.jpg","/images/9.jpg","/images/10.jpg"};

        String anyCotxes[] = {"Any: 2016","Any: 2018","Any: 2018","Any: 2020","Any: 2018",
                "Any: 2019","Any: 2021","Any: 2019","Any: 2019","Any: 2021"};

        String quilometresCotxes[] = {"Quilòmetres: 100.041 km","Quilòmetres: 43.416 km","Quilòmetres: 64.000 km","Quilòmetres: 43.853 km","Quilòmetres: 108.406 km",
                "Quilòmetres: 59.995 km","Quilòmetres: 58.375 km","Quilòmetres: 69.234 km","Quilòmetres: 143.000 km","Quilòmetres: 13.469 km"};

        String combustibleCotxes[] = {"Combustible: Dièsel","Combustible: Diésel","Combustible: Benzina","Combustible: Benzina","Combustible: Híbrid",
                "Combustible: Dièsel","Combustible: Dièsel","Combustible: Benzina","Combustible: Dièsel","Combustible: Dièsel"};

        String motorCotxes[] = {"Motor: 1.6 / 120 CV","Motor: 1.5 / 105 CV","Motor: 1.2 / 82 CV","Motor: 1.2 / 69 CV","Motor: 2.5 / 197 CV",
                "Motor: 2 / 150 CV","Motor: 2 / 150 CV","Motor: 1 / 125 CV","Motor: 2 / 150 CV","Motor: 1.5 / 100 CV"};

        String preuCotxes[] = {"Preu: 16.990 €","Preu: 18.990 €","Preu: 10.890 €","Preu: 11.990 €","Preu: 23.990 €",
                "Preu: 22.890 €","Preu: 34.490 €","Preu: 17.990 €","Preu: 24.990 €","Preu: 15.990 €"};

        for(int i = 0; i < nomsCotxes.length ;i++){

            cotxe = new Cotxe();

            cotxe.setName(nomsCotxes[i]);

            Image img = null;

            try {

                img = new Image(getClass().getResourceAsStream(imatgesCotxes[i]));

            }
            catch(Exception e) {
                e.printStackTrace();
            }

            cotxe.setImgSrc(img);
            cotxe.setColor("5D6D7E");
            cotxe.setAny(anyCotxes[i]);
            cotxe.setQuilometres(quilometresCotxes[i]);
            cotxe.setCombustible(combustibleCotxes[i]);
            cotxe.setMotor(motorCotxes[i]);
            cotxe.setPreu(preuCotxes[i]);

            cotxes.add(cotxe);
        }

        return cotxes;

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        cotxe.addAll(getData());

        int column = 0;
        int row = 1;

        try {

            for(int i = 0; i < cotxe.size();i++){

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("itemMobil.fxml"));

                AnchorPane anchorPane = fxmlLoader.load();

                ItemController item = fxmlLoader.getController();
                item.setData(cotxe.get(i),listener);


                if(column == 2){
                    column = 0;
                    row++;
                }


                grid.add(anchorPane, column++, row);

                //set grid width
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_COMPUTED_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_COMPUTED_SIZE);

                GridPane.setMargin(anchorPane,new Insets(10));

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    private void pujarCotxe(ActionEvent mouseEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(AppMobil.class.getResource("CotxesMobil_PujarCotxe.fxml"));

        Parent root = loader.load();

        ControllerMobilPujarCotxe controlador = loader.getController();

        Scene scene = new Scene(root);
        Stage stage = new Stage();

        stage.setScene(scene);
        stage.show();

        stage.setOnCloseRequest(e -> {
            try {
                controlador.closeWindows();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });


        Stage myStage = (Stage) this.btnPujarCotxe.getScene().getWindow();
        myStage.close();

    }

    @FXML
    private void missatges(MouseEvent mouseEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(AppMobil.class.getResource("CotxesMobil_missatges.fxml"));

        Parent root = loader.load();

        ControllerMobilMissatges controlador = loader.getController();

        Scene scene = new Scene(root);
        Stage stage = new Stage();

        stage.setScene(scene);
        stage.show();

        stage.setOnCloseRequest(e -> {
            try {
                controlador.closeWindows();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });


        Stage myStage = (Stage) this.btnMissatges.getScene().getWindow();
        myStage.close();

    }



    @FXML
    private void dadesUsuari(MouseEvent mouseEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(AppMobil.class.getResource("CotxesMobil_DadesUsuari.fxml"));

        Parent root = loader.load();

        ControllerMobilDadesUsuari controlador = loader.getController();

        Scene scene = new Scene(root);
        Stage stage = new Stage();

        stage.setScene(scene);
        stage.show();

        stage.setOnCloseRequest(e -> {
            try {
                controlador.closeWindows();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });


        Stage myStage = (Stage) this.btnDadesUsuari.getScene().getWindow();
        myStage.close();

    }

}
