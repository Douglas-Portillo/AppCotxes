package com.example.projecte_uf2_m07;

import Model.Cotxe;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class ItemController {

    @FXML
    private ImageView cotxeImg;

    @FXML
    private Label nomCotxe;

    private ListenerCotxe listener;

    public Cotxe cotxe;
    @FXML
    private void click(MouseEvent mouseEvent) throws IOException {
       listener.onClickListener(cotxe);
    }

    @FXML
    private void cotxeEscollit(MouseEvent mouseEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(AppDesktop.class.getResource("CotxesMobil_CotxeEscollit.fxml"));

        Parent root = loader.load();

        ControllerMobilCotxeEscollit controlador = loader.getController();

        Scene scene = new Scene(root);
        Stage stage = new Stage();

        stage.setScene(scene);
        stage.show();

        stage.setOnCloseRequest(e -> {
            try {
                controlador.closeWindows();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });

        Stage myStage = (Stage) this.cotxeImg.getScene().getWindow();
        myStage.close();

    }

    public void setData(Cotxe cotxe,ListenerCotxe listener){
        this.cotxe = cotxe;
        this.listener = listener;
        nomCotxe.setText(cotxe.getName());
        cotxeImg.setImage(cotxe.getImgSrc());

    }

}
