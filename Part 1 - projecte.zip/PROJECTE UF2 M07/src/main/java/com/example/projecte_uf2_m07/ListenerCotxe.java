package com.example.projecte_uf2_m07;

import Model.Cotxe;

import java.io.IOException;

public interface ListenerCotxe {
    public void onClickListener(Cotxe cotxe) throws IOException;
}
