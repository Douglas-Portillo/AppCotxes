package com.example.projecte_uf2_m07;

public class Main {

    public static  void main(String[] args){

        AppDesktop.main(args);

    }

}
