module com.example.projecte_uf2_m07 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.projecte_uf2_m07 to javafx.fxml;
    exports com.example.projecte_uf2_m07;
}